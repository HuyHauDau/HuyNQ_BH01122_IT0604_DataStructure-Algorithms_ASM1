package asm1_datastructures_algorithms;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentInformationSystem{
    private final List<Student> students;
    private final Scanner scanner;
    public StudentInformationSystem(){
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }
    public void addStudent(){
        System.out.println("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.println("Enter student Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter student Marks: ");
        float mark = scanner.nextFloat();
        scanner.nextLine();
        
        students.add(new Student(id, name, mark));
        System.out.println("Student added successfully.");   
    }
    public void editStudent(){
        System.out.println("Enter student ID to edit: ");
        String id = scanner.nextLine();
        for (Student student : students){
            if (student.getID().equals(id)){
                System.out.println("Enter new name: ");
                String name = scanner.nextLine();
                System.out.println("Enter new marks: ");
                float mark = scanner.nextFloat();
                scanner.nextLine();                
                student.setName(name);
                student.setMark(mark);
                System.out.println("Student updated successfully");
                return;
            }
        }
    }
    public void sortStudent(){
        int n = students.size();
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (students.get(j).getMark() < students.get(j + 1).getMark()) {
                    Student temp = students.get(j);
                    students.set(j, students.get(j + 1));
                    students.set(j + 1, temp);
                    swapped = true;
                }
            }
            if (!swapped) break;
        } 
        System.out.println("Student sorted successfully");
    }
    public void delStudent(){
        System.out.println("Enter Student ID to delete: ");
        String id = scanner.nextLine();
        students.removeIf(student -> student.getID().equals(id));
        System.out.println("Student deleted successfully");
    }
    public void searchStudentByID(){
        System.out.println("Enter Student ID to search: ");
        String id = scanner.nextLine();
        for (Student student : students){
            if (student.getID().equals(id)){
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student not found");
    }
    public void displayAllStudents(){
    if (students.isEmpty()){
        System.out.println("No Students to display");
    } else{
        for (Student student : students){
            System.out.println(student);
        }
    }
    }
}


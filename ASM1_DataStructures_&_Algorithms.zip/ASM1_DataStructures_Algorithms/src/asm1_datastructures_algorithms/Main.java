/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asm1_datastructures_algorithms;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Consumer;

public class Main {
    public static void main(String[] args){
        StudentInformationSystem system = new StudentInformationSystem();
        Scanner scanner = new Scanner(System.in);
        
//        while(true){
//        System.out.println("1. Add Student");
//        System.out.println("2. Edit Student");
//        System.out.println("3. Delete Student");
//        System.out.println("4. Sort Student");
//        System.out.println("5. Search Student = ID");
//        System.out.println("6. Display All Students");
    Map<Integer, Runnable> options = new HashMap<>();
        options.put(1, system::addStudent);
        options.put(2, system::editStudent);
        options.put(3, system::delStudent);
        options.put(4, system::sortStudent);
        options.put(5, system::searchStudentByID);
        options.put(6, system::displayAllStudents);
//        System.out.println("Choose An Option: ");
//        int option = scanner.nextInt();
        
//        switch (option){
//            case 1 -> system.addStudent();
//            case 2 -> system.editStudent();
//            case 3 -> system.delStudent();
//            case 4 -> system.sortStudent();
//            case 5 -> system.searchStudentByID();
//            case 6 -> system.displayAllStudents();
//            default -> System.out.println("Invalid optioin. Please try again");
//            
//        }
    while(true){
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Sort Student");
            System.out.println("5. Search Student by ID");
            System.out.println("6. Display All Students");
            int option = scanner.nextInt();
            Runnable action = options.get(option);
            if (action != null) {
                action.run();
            } else {
                System.out.println("Invalid option. Please try again");
            }
        }

    }
}


